# 🎮 游戏高级编辑功能设计方案

> 文档创建时间：2026-01-17
> 功能目标：允许玩家对自己创作的游戏进行多轮对话式 AI 优化编辑

---

## 一、功能概述

**高级编辑** = 利用 LLM 对已有游戏代码进行**多轮对话式优化**，让玩家可以不断迭代改进自己的游戏。

### 核心价值
- 🔄 **迭代优化**：不满意可以多次修改，逐步完善
- 💬 **对话式交互**：像聊天一样描述修改需求
- 📜 **版本管理**：保留所有修改历史，可随时回滚
- 🎯 **智能建议**：AI 分析代码并推荐优化方向

### 工作流程图
```
┌─────────────────────────────────────────────────────────────┐
│                    高级编辑工作流程                          │
├─────────────────────────────────────────────────────────────┤
│  原始游戏 ──► 编辑请求 ──► LLM优化 ──► 预览 ──► 保存/发布   │
│              ↑_________________________________│             │
│                    多轮迭代优化                              │
└─────────────────────────────────────────────────────────────┘
```

---

## 二、编辑入口位置

### 入口1：游戏详情页
- 在游戏详情页右上角添加"✏️ 编辑"按钮
- 仅游戏作者可见

### 入口2：个人主页 - 我的作品
- 在"我的作品"列表中，长按游戏卡片
- 弹出操作菜单，包含"高级编辑"选项
- 菜单选项：查看、编辑、删除、设为私密

---

## 三、数据库设计

### 3.1 游戏编辑会话表
```sql
CREATE TABLE IF NOT EXISTS game_edit_sessions (
    id TEXT PRIMARY KEY,                    -- 会话ID（UUID）
    game_id TEXT NOT NULL,                  -- 关联的游戏ID
    user_token TEXT NOT NULL,               -- 用户Token
    original_code TEXT NOT NULL,            -- 编辑开始时的原始代码
    current_code TEXT NOT NULL,             -- 当前最新代码
    status TEXT DEFAULT 'active',           -- 状态: active/completed/abandoned
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

### 3.2 编辑对话历史表
```sql
CREATE TABLE IF NOT EXISTS game_edit_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT NOT NULL,               -- 关联的会话ID
    role TEXT NOT NULL,                     -- user/assistant
    content TEXT NOT NULL,                  -- 消息内容
    code_snapshot TEXT,                     -- 此轮修改后的代码快照
    tokens_used INTEGER,                    -- 消耗的tokens
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

### 3.3 游戏版本历史表
```sql
CREATE TABLE IF NOT EXISTS game_versions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    game_id TEXT NOT NULL,                  -- 游戏ID
    version_number INTEGER NOT NULL,        -- 版本号
    code TEXT NOT NULL,                     -- 该版本的代码
    change_summary TEXT,                    -- 变更摘要
    created_by TEXT,                        -- 创建者
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

### 3.4 索引
```sql
CREATE INDEX IF NOT EXISTS idx_edit_sessions_game ON game_edit_sessions(game_id);
CREATE INDEX IF NOT EXISTS idx_edit_sessions_user ON game_edit_sessions(user_token);
CREATE INDEX IF NOT EXISTS idx_edit_messages_session ON game_edit_messages(session_id);
CREATE INDEX IF NOT EXISTS idx_game_versions ON game_versions(game_id, version_number DESC);
```

---

## 四、API 设计

### API 文件位置
`api/games/[id]/edit.js`

### 接口列表

| 操作 | action 参数 | 请求参数 | 返回值 |
|------|-------------|----------|--------|
| 开始编辑会话 | `start` | - | sessionId, suggestions |
| 发送编辑请求 | `message` | sessionId, message | code, changes |
| 预览效果 | `preview` | sessionId | code |
| 保存修改 | `save` | sessionId, saveAsNew, title | gameId, version |
| 查看历史 | `history` | - | versions, sessions |
| 版本回滚 | `rollback` | versionId | version |
| 快速编辑 | `quick` | editPrompt | code, version |

### 请求示例

#### 开始编辑
```javascript
POST /api/games/{gameId}/edit
Headers: { "X-User-Token": "xxx" }
Body: { "action": "start" }

Response: {
  "success": true,
  "sessionId": "uuid-xxx",
  "game": { "id", "title", "prompt", "codeLength" },
  "suggestions": ["🎨 添加背景效果", "🔊 添加音效", ...]
}
```

#### 发送修改请求
```javascript
POST /api/games/{gameId}/edit
Headers: { "X-User-Token": "xxx" }
Body: {
  "action": "message",
  "sessionId": "uuid-xxx",
  "message": "把背景改成星空效果，并添加射击音效"
}

Response: {
  "success": true,
  "code": "<!DOCTYPE html>...",
  "message": "修改完成！",
  "changes": ["添加了音效", "修改了背景"],
  "tokensUsed": 2500,
  "apiTime": 8500
}
```

#### 保存修改
```javascript
POST /api/games/{gameId}/edit
Headers: { "X-User-Token": "xxx" }
Body: {
  "action": "save",
  "sessionId": "uuid-xxx",
  "saveAsNew": false,  // true = 另存为新游戏
  "title": "新游戏标题"  // 仅 saveAsNew=true 时需要
}

Response: {
  "success": true,
  "gameId": "xxx",
  "version": 3,
  "message": "游戏已更新"
}
```

---

## 五、前端实现

### 5.1 编辑入口

#### 游戏详情页按钮
```html
<button class="btn-edit-game" onclick="openGameEditor('${gameId}')">
  ✏️ 编辑游戏
</button>
```

#### 长按菜单选项
```javascript
// 在长按菜单中添加"高级编辑"选项
const menuItems = [
  { icon: '👁️', text: '查看游戏', action: 'view' },
  { icon: '✏️', text: '高级编辑', action: 'edit' },  // 新增
  { icon: '🔒', text: '设为私密', action: 'private' },
  { icon: '🗑️', text: '删除游戏', action: 'delete' }
];
```

### 5.2 编辑页面布局

```
┌────────────────────────────────────────────────────────┐
│  ← 返回    游戏编辑 - 贪吃蛇              保存 ▼      │
├────────────────────────────────────────────────────────┤
│  ┌──────────────────────────────────────────────────┐  │
│  │                                                  │  │
│  │                  游戏预览区域                     │  │
│  │                 (iframe 实时预览)                 │  │
│  │                                                  │  │
│  └──────────────────────────────────────────────────┘  │
├────────────────────────────────────────────────────────┤
│  📝 AI 编辑建议：                                      │
│  ┌────────┐ ┌────────┐ ┌────────┐ ┌────────┐          │
│  │🎨 背景 │ │🔊 音效 │ │💾 存档 │ │✨ 特效 │          │
│  └────────┘ └────────┘ └────────┘ └────────┘          │
├────────────────────────────────────────────────────────┤
│  💬 对话记录：                                         │
│  ┌──────────────────────────────────────────────────┐  │
│  │ 🤖 AI: 游戏分析完成，有以下优化建议...           │  │
│  │ 👤 我: 添加星空背景                              │  │
│  │ 🤖 AI: ✅ 已添加星空背景效果                    │  │
│  │ 👤 我: 再加个背景音乐                            │  │
│  │ 🤖 AI: ✅ 已添加背景音乐                        │  │
│  └──────────────────────────────────────────────────┘  │
├────────────────────────────────────────────────────────┤
│  ┌────────────────────────────────────────┐ ┌──────┐  │
│  │ 输入你的修改要求...                     │ │ 发送 │  │
│  └────────────────────────────────────────┘ └──────┘  │
└────────────────────────────────────────────────────────┘
```

### 5.3 核心前端函数

```javascript
// 打开编辑器
async function openGameEditor(gameId) {
  // 1. 调用 start API
  const res = await fetch(`/api/games/${gameId}/edit`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-User-Token': userToken },
    body: JSON.stringify({ action: 'start' })
  });
  const data = await res.json();
  
  // 2. 显示编辑页面
  showEditPage(gameId, data.sessionId, data.suggestions);
}

// 发送编辑消息
async function sendEditMessage(gameId, sessionId, message) {
  // 显示用户消息
  appendMessage('user', message);
  
  // 调用 API
  const res = await fetch(`/api/games/${gameId}/edit`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-User-Token': userToken },
    body: JSON.stringify({ action: 'message', sessionId, message })
  });
  const data = await res.json();
  
  // 显示 AI 回复
  appendMessage('assistant', data.message);
  
  // 更新预览
  updatePreview(data.code);
}

// 保存修改
async function saveEdit(gameId, sessionId, saveAsNew = false) {
  const res = await fetch(`/api/games/${gameId}/edit`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-User-Token': userToken },
    body: JSON.stringify({ action: 'save', sessionId, saveAsNew })
  });
  const data = await res.json();
  
  showToast(data.message, 'success');
  // 返回游戏页面
}
```

---

## 六、用户体验流程

### 流程1：从游戏详情页进入编辑
```
1. 用户打开自己的游戏详情页
2. 看到右上角"编辑"按钮，点击
3. 进入编辑页面，显示游戏预览和 AI 建议
4. 输入修改要求，如"添加背景音乐"
5. AI 返回修改后的代码，预览区实时更新
6. 满意后点击保存，选择"更新原游戏"或"另存为新游戏"
7. 保存成功，返回游戏详情页
```

### 流程2：从个人主页长按进入编辑
```
1. 用户进入"我的主页" → "我的作品"
2. 长按某个游戏卡片
3. 弹出操作菜单，选择"高级编辑"
4. 进入编辑页面
5. ... (后续同流程1)
```

---

## 七、实施计划

### 阶段1：后端 API（已完成 ✅）
- [x] 创建 `api/games/[id]/edit.js`
- [x] 实现会话管理
- [x] 实现多轮对话
- [x] 实现版本历史
- [x] 实现回滚功能

### 阶段2：前端 - 编辑页面
- [ ] 创建编辑页面 HTML 结构
- [ ] 实现对话界面
- [ ] 实现实时预览
- [ ] 实现建议标签点击
- [ ] 实现保存选项弹窗

### 阶段3：前端 - 入口集成
- [ ] 游戏详情页添加编辑按钮
- [ ] 长按菜单添加编辑选项
- [ ] 权限验证（仅作者可见）

### 阶段4：版本历史界面
- [ ] 版本历史列表
- [ ] 版本对比功能
- [ ] 一键回滚功能

---

## 八、后续优化方向

1. **AI 自动检测问题** - 自动分析游戏代码，发现 bug 并建议修复
2. **模板应用** - 提供常用修改模板（如"添加暗黑模式"、"添加排行榜"）
3. **协作编辑** - 允许多人共同编辑同一游戏
4. **A/B 测试** - 同时维护多个版本，测试哪个更受欢迎
5. **编辑审核** - 对修改后的内容进行安全审核
6. **差异对比** - 可视化展示每次修改的代码差异

---

## 九、相关文件

| 文件 | 说明 |
|------|------|
| `api/games/[id]/edit.js` | 编辑 API 接口 |
| `public/js/app.js` | 前端主逻辑（需修改） |
| `public/css/style.css` | 样式文件（需添加编辑页面样式） |
| `public/index.html` | 主页面（需添加编辑页面 HTML） |